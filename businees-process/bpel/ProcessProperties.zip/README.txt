This sample demonstrates the use of xpath function ode:process-property($name as item()) as node().
This is a function that allows you to retrieve the value of a property, defined in deploy.xml for the current process, with the given name (specified by the $name argument in the signature below, which is either a QName, String, Element or Single-Valued List).
