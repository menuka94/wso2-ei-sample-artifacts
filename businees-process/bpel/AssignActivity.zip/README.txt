This sample demonstrates different use cases how assign operation can be used.

1. Assigning variable part value to another variable.
2. Assigning variable value to another variable's part value.
3. Assigning a string literal  to a variable .
4. Assigning from expression to variable.
5. Assigning from variable to variable.
6. Assigning value of  a variable with a logical expression to a another variable.
7. Assigning value of a variable with boolean expression to another variable.